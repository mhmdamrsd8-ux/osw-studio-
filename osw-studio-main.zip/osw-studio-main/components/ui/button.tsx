import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center cursor-pointer justify-center gap-2 whitespace-nowrap rounded-full text-sm font-sans font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",
  {
    variants: {
      variant: {
        // Neutral by default (matches the outline/nav treatment) instead of the glaring orange
        // primary fill. Primary actions across the app inherit this via the `default` fallback.
        default:
          "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
        destructive:
          "bg-red-500 text-white shadow-xs hover:bg-destructive/90 focus-visible:ring-destructive/20 [&_svg]:!text-white",
        // The emphasis treatment for a primary action that commits to something. Muted orange,
        // matching a selected segment in the Inspector's Styles panel (bg-primary/15 + text-primary):
        // a tinted fill, not a solid one, so orange stays a signal rather than the default. Full
        // solid orange is spent only on small accents (active tab underline, status dots).
        accent:
          "bg-primary/15 text-primary border border-primary/40 shadow-xs hover:bg-primary/25 focus-visible:ring-primary/20",
        outline:
          "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",
        secondary:
          "bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
        ghost:
          "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        lightGray: "bg-neutral-200/60 hover:bg-neutral-200",
        link: "text-primary underline-offset-4 hover:underline",
        ghostDarker:
          "text-white shadow-xs focus-visible:ring-black/40 bg-black/40 hover:bg-black/70",
        black: "bg-neutral-950 text-neutral-300 hover:brightness-110",
        sky: "bg-sky-500 text-white hover:brightness-110",
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-full text-[13px] gap-1.5 px-3",
        lg: "h-10 rounded-full px-6 has-[>svg]:px-4",
        icon: "size-9",
        iconXs: "size-7",
        iconXss: "size-6",
        xs: "h-6 text-xs rounded-full pl-2 pr-2 gap-1",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

function Button({
  className,
  variant,
  size,
  asChild = false,
  ...props
}: React.ComponentProps<"button"> &
  VariantProps<typeof buttonVariants> & {
    asChild?: boolean;
  }) {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
}

export { Button, buttonVariants };
