# Welcome to OSW Studio

**Build websites by chatting with AI. No coding required.**

OSW Studio is a browser-based development environment where you describe what you want, and AI builds it for you. Create complete websites with HTML, CSS, and JavaScript through natural conversation.

## What You Can Build

- Personal websites and portfolios
- Landing pages and marketing sites
- Blogs and documentation sites
- Interactive web applications
- Python and Lua scripts with an interactive console
- Anything that runs in a browser (HTML/CSS/JS, Handlebars, React, Preact, Svelte, Vue, Python, Lua)

## How It Works

1. **Chat with AI** - Describe your website in plain English
2. **Watch it build** - AI creates files, writes code, and explains what it's doing
3. **See it live** - Preview your site in real-time as it's being built
4. **Export & deploy** - Download your site and publish to Vercel, Netlify, or any static host

## Key Features

**🤖 Multiple AI Providers**
Choose from 16 providers: OpenRouter, OpenAI, Anthropic, Google Gemini, Groq, HuggingFace, DeepSeek, SambaNova, MiniMax, Zhipu, Opencode Go, mesh-llm, ChatGPT subscription (Plus/Pro), or run locally with Ollama, LM Studio, or llama.cpp

**💾 Works in Your Browser**
Everything stays private in your browser. No server required.

**🖥️ Desktop App**
Native app for macOS, Windows, and Linux with built-in publishing and sync

**🎨 Live Preview**
See your website update in real-time as AI builds it

**🧱 Semantic Blocks**
Drag 36 pre-defined blocks (heroes, forms, pricing, galleries) onto the preview — the AI writes code that fits your project's style

**📦 Export Ready**
Download complete, deployable websites with one click

**🎯 Templates & Skills**
Start from 20 built-in templates or teach AI your preferred workflows

## Two Modes

**Browser Mode** (default) -- everything runs in your browser. No server, no account, complete privacy. Export your site as a ZIP and deploy anywhere.

**Server Mode** -- self-host for teams or clients. Adds workspaces (isolated environments with their own projects and deployments), user accounts with role-based access, static site publishing, databases, and an admin dashboard. See **[Server Mode](?doc=server-mode)** and **[Multitenancy](?doc=multitenancy)**.

## Who Is This For?

- **Non-developers** who want to build websites without learning code
- **Designers** who want to prototype ideas quickly
- **Developers** who want AI assistance for web projects
- **Agencies** who want to host client sites and let clients make updates via AI
- **Teams** who want a shared web development platform

## Quick Start

Ready to build your first website?

👉 **[Get Started](?doc=getting-started)** - 5 minute setup guide

## Need Help?

- **[FAQ](?doc=faq)** - Common questions answered
- **[Troubleshooting](?doc=troubleshooting)** - Fix common issues
- **[GitHub](https://github.com/o-stahl/osw-studio)** - Report bugs or request features
